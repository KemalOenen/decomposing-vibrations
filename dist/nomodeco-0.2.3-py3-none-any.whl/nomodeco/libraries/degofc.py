from __future__ import annotations

import itertools
from typing import NamedTuple
import numpy as np
from mendeleev.fetch import fetch_table
import string



